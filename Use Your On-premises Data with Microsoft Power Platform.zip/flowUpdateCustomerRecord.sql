--------------------------------------------------------------------------------------------
-- This stored procedure is a wrapper to eConnect stored procedure taUpdateCreateCustomerRcd
-- Created by Mariano Gomez, MVP
-- Microsoft Dynamics GP Technical Conference 2019
---------------------------------------------------------------------------------------------
create procedure flowUpdateCustomerRecord 
	@I_vCUSTNMBR varchar(15),
	@I_vCNTCPRSN varchar(60),
	@I_vPHNUMBR1 varchar(21),
	@RC int OUTPUT,
	@O_iErrorState int OUTPUT,
	@oErrString varchar(255) OUTPUT
AS

EXEC	@RC = [dbo].[taUpdateCreateCustomerRcd]
		@I_vCUSTNMBR = @I_vCUSTNMBR,
		@I_vCNTCPRSN = @I_vCNTCPRSN,
		@I_vPHNUMBR1 = @I_vPHNUMBR1,
		@I_vUpdateIfExists = 1,
		@O_iErrorState = @O_iErrorState OUTPUT,
		@oErrString = @oErrString OUTPUT
GO
